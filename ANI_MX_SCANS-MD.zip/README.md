# 🌎 🌎ANI MX SCANS🌏 🌏
Bot promocional del proyecto 🌎ANI MX SCANS🌏 by ㄖㄒ卂Ҡ凵丂 ㄒㄖᎶ乇ㄒ卄乇尺

UN AGRADECIMIENTO MUY ESPECIAL A MI MAESTRO BRUNO SOBRINO QUÉ ME AYUDÓ A DARLE VIDA A MIS BOTS.
(El otro bot es privado solo este se conoce entrando a los siguientes grupos y contestando una pequeña entrevista dentro de ellos para entrar al grupo principal:

*_1.-_* <a href="https://chat.whatsapp.com/L4VRAzaYc11D4LSpt8rB9W" target="blank"><img src="https://img.shields.io/badge/𝕃𝕠𝕓𝕓𝕪_𝕕𝕖_𝕆𝕥𝕒𝕜𝕦𝕤_𝕋𝕠𝕘𝕖𝕥𝕙𝕖𝕣-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

*_2.-_* <a href="https://chat.whatsapp.com/H0SheP7ippc1dF9uxL04Gt" target="blank"><img src="https://img.shields.io/badge/ℂ𝕒𝕗𝕖𝕔𝕚𝕥𝕠_ℍ𝕠𝕣𝕚_𝕊𝕒𝕟𝕕𝕚𝕒🍉☕🥢-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

### `—◉ 👑 PARA CUALQUIER DUDA QUE PUEDA SURGIR CON ESTAS EDICIONES DEL BOT (INCLUYENDO FALTAS DE ORTOGRAFIA :v), CONTACTANOS 👑`
<a href="http://wa.me/5219992095479" target="blank"><img src="https://img.shields.io/badge/BRUNO_SOBRINO_MAESTRO-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

<a href="http://wa.me/5215533827255" target="blank"><img src="https://img.shields.io/badge/𝓡𝓮𝔂_𝓔𝓷𝓭𝔂𝓶𝓲𝓸𝓷-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

### `—◉ 💰 DONAR 💰`
- AGRADECE CON UNA DONACION VOLUNTARIA A MI MAESTRO 👺🤙🏻 [Aqui](https://www.paypal.me/TheShadowBrokers133)

- APOYO AL PROYECTO DE TRADUCCION 👺👌🏼 [Aqui](https://www.paypal.me/AMxScan)

### `—◉ 🖍 LETRA DEL BOT 🖍`
- EDICIÓN DE TEXTO PLANO SIN NINGUNA CLASE DE TIPOGRAFÍA PARA MEJOR COMODIDAD VISUAL

### `—◉ ⚙️ AJUSTES ⚙️`
- CLONAR EL REPOSITORIO [Aqui](https://github.com/ReyEndymion/ANI_MX_SCANS-MD/fork)
- CAMBIAR NÚMERO DEL OWNER [Aqui](https://github.com/ReyEndymion/ANI_MX_SCANS-MD/blob/master/config.js)

### `—◉ 👾 ACTIVAR EN TERMUX 👾`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd
> termux-setup-storage
> apt update 
> pkg upgrade 
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> pkg install yarn
> git clone https://github.com/ReyEndymion/ANI_MX_SCANS-MD
> cd ANI_MX_SCANS-MD
> yarn install 
> npm update
> npm start
```

### `—◉ ✔️ ACTIVAR EN CASO DE DETENERSE ✔️`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd ANI_MX_SCANS-MD
> npm start
```

### `—◉ 👽 OBTENER OTRO CODIGO QR 👽`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd ANI_MX_SCANS-MD
> rm -rf session.data.json
> npm start
```

### `—◉ 🔥 ACTIVAR EN BOXMINEHOST 🔥`
<a href="https://boxmineworld.com"><img src="https://raw.githubusercontent.com/BrunoSobrino/ANI_MX_SCANS-MD/master/src/Pre%20Bot%20Publi.png" width="450" height="240" alt="JPG"/></a>
<p>> Pagina Oficial:
<a href="https://boxmineworld.com">https://boxmineworld.com</a>
<p>> Dashboard:
<a href="https://dash.boxmineworld.com/home">https://dash.boxmineworld.com/home</a>
<p>> Panel:
<a href="https://panel.boxmineworld.com">https://panel.boxmineworld.com</a>
<p>> Tutorial:
<a href="https://youtu.be/eC9TfKICpcY">https://youtu.be/eC9TfKICpcY</a>
<p>> Dudas UNICAMENTE SOBRE EL HOST:
<a href="https://discord.gg/84qsr4v">https://discord.gg/84qsr4v</a> (Preguntar por Vicemi)
</p>

### `—◉ 📝 NOTAS 📝`
```bash
- ES POSIBLE QUE EL BOT TENGA ALGUNAS FALLAS, SE IRAN SOLUCIONANDO CONFORME SE VAYAN DETECTANDO
- SI VAS A EDITAR POR COMPLETO DEJA LOS CREDITOS DEL BOT 
- EL BOT ES COMPARTIBLE CON WHATSAPP NORMAL O BUSINESS
- ATENTO A LAS ACTUALIZACIONES QUE SE HAGAN EN ESTE REPOSITORIO
- EL ADD Y EL KICK PUEDEN OCASIONAR QUE EL NUMERO SE VAYA A SOPORTE POR ELLO SE ACTIVA CON #enable restrict 
- 🌎ANI MX SCANS🌏 NO SE HACE RESPONSABLE DEL USO, NUMEROS, PRIVACIDAD Y CONTENIDO MANDADO, USADO O GESTIONADO POR USTEDES O EL BOT
```

## `COLABORADORES DEL BOT` 
<a href="https://github.com/BrunoSobrino"><img src="https://github.com/BrunoSobrino.png" width="300" height="300" alt="BrunoSobrino"/></a>

## `EDITOR Y PROPIETARIO DEL BOT` 
<a href="https://github.com/ReyEndymion"><img src="https://github.com/ReyEndymion.png" width="300" height="300" alt="BrunoSobrino"/></a>

`ANI_MX_SCANS-MD _ By Rey Endymion`

POWERED BY BRUNO SOBRINO & The Shadow Brokers

https://github.com/BrunoSobrino

https://github.com/BrunoSobrino/TheMystic-Bot-MD
