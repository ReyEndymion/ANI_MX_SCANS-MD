let handler = async (m) => {
    m.reply(
    `
    *NOMBRE*:
    
    
     *EDAD*:
    
    
     *PAÍS* :
    
    
     *WAIFU O HUSBANDO*:
    
    
     *ANIME FAVORITO*: 
    
    
      *MANGA FAVORITO* :
    
    
     *DESDE HACE CUÁNTO ERES OTAKU*:
    
    
     *FOTO o MENSAJE DE VOZ*:
    
    
    **TODOS ESTOS DATOS PUEDEN SER EN PRIVADO SI QUIEREN CON ALGUNO DE LOS ADMINS ACTIVOS**
    `
    )}
    handler.customPrefix = /ficha|Ficha/i
    handler.command = new RegExp
    handler.fail = null
    export default handler
    